from pydantic import BaseModel
from beanie import Document


class about(BaseModel):
    pass