from beanie import Document


class real_history(Document):
    title: str
    content: str
